Calendar._SDN = new Array
("Dom",
 "Lun",
 "Mar",
 "Mer",
 "Gio",
 "Ven",
 "Sab",
 "Dom");
 Calendar._TT["ABOUT"] =
"Selezionare la data :\n" +
"- Usa i pulsanti \xab, \xbb  per selezionare l\'anno\n" +
"- Usa i pulsanti " + String.fromCharCode(0x2039) + ", " + String.fromCharCode(0x203a) + " per selezionare i mesi\n" +
"- Tenete il mouse su ogni pulsante per la selezione rapida";