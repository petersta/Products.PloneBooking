Calendar._SDN = new Array
("So",
 "Mo",
 "Di",
 "Mi",
 "Do",
 "Fr",
 "Sa",
 "So");
 Calendar._TT["ABOUT"] =
"Wahl des Datums:\n" +
"- Benutzen Sie die Buttons \xab, \xbb  um das Jahr zu selektieren\n" +
"- Benutzen Sie die Buttons " + String.fromCharCode(0x2039) + ", " + String.fromCharCode(0x203a) + " um den Monat zu selektieren\n" +
"- F\u00fcr eine Schnellauswahl halten Sie die Maustaste \u00fcber diesen Buttons fest.";