# -*- coding: utf-8 -*-
## PloneBooking: Online Booking Tool to allow booking on any kind of ressource
## Copyright (C)2005 Ingeniweb

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; see the file COPYING. If not, write to the
## Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
"""
    PloneBooking Tool
"""

__version__ = "$Revision: 1.25 $"
__author__ = ''
__docformat__ = 'restructuredtext'

# Python imports
import re
import math
from types import StringType

# Zope imports
from App.class_init import InitializeClass
from AccessControl import ClassSecurityInfo
from OFS.SimpleItem import SimpleItem

#from OFS.PropertyManager import PropertyManager
from DateTime import DateTime

# CMF imports
from Products.CMFCore import permissions
from Products.CMFCore.ActionProviderBase import ActionProviderBase
from Products.CMFCore.utils import getToolByName
from Products.CMFCore.utils import UniqueObject


# Archetypes imports
from Products.Archetypes.public import Vocabulary

# PloneBooking imports
from Products.PloneBooking.DateManager import DateManager
from Products.PloneBooking.content.vocabulary import CALENDAR_VIEWS, VIEW_MODES, LISTING_VIEWS
from Products.PloneBooking.config import I18N_DOMAIN

from Products.PloneBooking import PloneBookingFactory as _

# Constants
ESCAPE_CHARS_RE = r'[\t\r\n\"\']'
ESCAPE_CHARS = re.compile(ESCAPE_CHARS_RE)


class BookingTool(DateManager, UniqueObject, SimpleItem, ActionProviderBase):
    """Tool for PloneBooking
    """

    plone_tool = 1
    id = 'portal_booking'
    title = "Misc utilities for PloneBooking application"
    meta_type = "BookingTool"

    manage_options = (ActionProviderBase.manage_options + SimpleItem.manage_options)
    security = ClassSecurityInfo()

    security.declarePublic('isBooked')
    def isBooked(self, b_start, b_end, start, end):
        """
        b_start: timestamp. Beginning date of booking
        b_end: timestamp. Ending date of booking
        start: timestamp. Beginning date of tested period
        end: timestamp. Ending date of tested period

        return is_booked: boolean
        """
        is_booked = False

        if b_start < start:
            if b_end > start:
                is_booked = True
        else:
            if b_end < end or b_start < end:
                is_booked = True

        return is_booked

    security.declarePublic('filterBookingBrains')
    def filterBookingBrains(self, booking_brains, start_date, end_date):
        """Returns brains  booked in interval of start date and end date
        """

        result = []
        for brain in booking_brains:
            booking_start_date = brain['start']
            booking_end_date = brain['end']
            is_booked = self.isBooked(booking_start_date, booking_end_date, start_date, end_date)
            if is_booked:
                result.append(brain)
        return result

    security.declarePublic('getPeriodicBookingBrains')
    def getAllPeriodicBookingBrains(self, booking_uid):
        """Returns periodic brains for a booking.
        """

        atool = getToolByName(self, 'archetype_tool')
        obj = atool.getObject(booking_uid)
        return obj.getAllPeriodicBookingBrains()

    security.declarePublic('cancelBooking')
    def cancelBooking(self, booking):
        """Delete the booking
        """
        booking_id = booking.getId()
        booked_object = booking.getBookedObject()

        # delete booking
        booked_object.manage_delObjects([booking_id])

    security.declarePublic('getBookingDefaultTitle')
    def getBookingDefaultTitle(self):
        """Returns booking default title.
        It is used when no title is defined on booking"""

        return _("label_booking", default=u"Booking")

    security.declarePublic('buildFilter')
    def buildFilter(self, **kwargs):
        """Returns a dictionnary using kwargs.  Removes None values.
        """
        result = {}
        for key, value in kwargs.items():
            if value is not None:
                result[key] = value
        return result

    security.declarePublic('getIntervalOfMinutesGroupKeys')
    def getIntervalOfMinutesGroupKeys(self, start_date, end_date, interval):
        """
        """
        group_keys = []
        interval_in_seconds = interval * 60.0

        # Round start date and end date to interval
        start_ts = self.zdt2ts(start_date)
        start_ts_from_zero = self.zdt2ts(DateTime(
            start_date.year(), start_date.month(), start_date.day())
            )
        new_start_ts = start_ts_from_zero + math.floor((start_ts - start_ts_from_zero) / interval_in_seconds) * interval_in_seconds
        new_start_dt = self.ts2zdt(new_start_ts)
        end_ts = self.zdt2ts(end_date)
        end_ts_from_zero = self.zdt2ts(DateTime(end_date.year(), end_date.month(), end_date.day()))
        new_end_ts = end_ts_from_zero + math.ceil((end_ts - end_ts_from_zero) / interval_in_seconds) * interval_in_seconds
        nb_intervals = int((new_end_ts - new_start_ts) / interval_in_seconds)

        for i in range(0, nb_intervals):
            key_date = new_start_dt + (i * (interval_in_seconds / 86400.0))
            key_interval = (key_date.hour() * 60 + key_date.minute())
            group_keys.append((key_date.year(), key_date.month(), key_date.day(), key_interval))
        return group_keys

    security.declarePublic('getDayGroupKeys')
    def getDayGroupKeys(self, start_date, end_date):
        """
        """
        group_keys = []
        interval_in_seconds = 86400.0

        # Round start date and end date to day
        new_start_ts = self.zdt2ts(DateTime(start_date.year(), start_date.month(), start_date.day()))
        new_start_dt = self.ts2zdt(new_start_ts)
        end_ts = self.zdt2ts(end_date)
        end_ts_from_zero = self.zdt2ts(DateTime(end_date.year(), end_date.month(), end_date.day()))
        new_end_ts = end_ts_from_zero + math.ceil((end_ts - end_ts_from_zero) / interval_in_seconds) * interval_in_seconds
        nb_days = int((new_end_ts - new_start_ts) / interval_in_seconds)

        for i in range(0, nb_days):
            key_date = new_start_dt + i
            group_keys.append((key_date.year(), key_date.month(), key_date.day()))
        return group_keys

    security.declarePublic('getWeekGroupKeys')
    def getWeekGroupKeys(self, start_date, end_date):
        """
        """
        group_keys = []
        interval_in_seconds = 7 * 86400.0

        # Assume monday is the first day of the week and sunday is the last day
        # of the week
        # FIXME: Should find an alternate method for local convention

        new_start_dt = DateTime(start_date.year(), start_date.month(), start_date.day()) - (start_date.dow() - 1) % 7  # Get the monday before start_date
        new_start_ts = self.zdt2ts(new_start_dt)
        end_ts = self.zdt2ts(end_date)
        end_ts_from_zero = self.zdt2ts((DateTime(end_date.year(), end_date.month(), end_date.day()) - (end_date.dow() - 1) % 7))
        new_end_ts = end_ts
        if end_ts != end_ts_from_zero:
            new_end_ts += interval_in_seconds

        nb_weeks = int((new_end_ts - new_start_ts) / interval_in_seconds)

        for i in range(0, nb_weeks):
            key_date = new_start_dt + (i * 7)
            group_keys.append((key_date.year(), key_date.week()))
        return group_keys

    security.declarePublic('getMonthGroupKeys')
    def getMonthGroupKeys(self, start_date, end_date):
        """"""

        group_keys = []

        end_ts = self.zdt2ts(end_date)
        end_ts_from_zero = self.zdt2ts(DateTime(end_date.year(), end_date.month(), 1))
        end_year = end_date.year()
        end_month = end_date.month()
        if end_ts == end_ts_from_zero:
            if end_month == 1:
                end_month = 12
                end_year -= 1
            else:
                end_month -= 1

        # Round start date and end date to month
        start_months = (start_date.year() * 12 + start_date.month())
        end_months = (end_year * 12 + end_month)
        nb_months = end_months - start_months + 1

        for i in range(0, nb_months):
            new_month = (start_months + i - 1) % 12 + 1
            new_year = (start_months + i - 1) / 12
            group_keys.append((new_year, new_month))
        return group_keys

    security.declarePublic('getYearGroupKeys')
    def getYearGroupKeys(self, start_date, end_date):
        """"""

        group_keys = []

        end_ts = self.zdt2ts(end_date)
        end_ts_from_zero = self.zdt2ts(DateTime(end_date.year(), 1, 1))
        end_year = end_date.year()

        if end_ts == end_ts_from_zero:
            end_year -= 1
        new_start_dt, new_end_dt = self.getDateRangeFromYear(start_date.year(), end_year)
        first_year = new_start_dt.year()
        nb_years = new_end_dt.year() - first_year

        for i in range(0, nb_years):
            group_keys.append(first_year + i)
        return group_keys

    security.declarePublic('getViewModeDisplayList')
    def getViewModeDisplayList(self):
        """Returns view mode display list
        """
        return VIEW_MODES

    security.declarePublic('getListingViewDisplayList')
    def getListingViewDisplayList(self):
        """Returns listing view display list
        """
        return LISTING_VIEWS

    security.declarePublic('getCalendarViewDisplayList')
    def getCalendarViewDisplayList(self):
        """Returns listing view display list
        """
        return CALENDAR_VIEWS

    security.declarePublic('getViewModeVocabulary')
    def getViewModeVocabulary(self):
        """Returns view mode vocabulary
        """
        dl = self.getViewModeDisplayList()
        return Vocabulary(dl, self, I18N_DOMAIN)

    security.declarePublic('getListingViewVocabulary')
    def getListingViewVocabulary(self):
        """Returns listing view vocabulary
        """
        dl = self.getListingViewDisplayList()
        return Vocabulary(dl, self, I18N_DOMAIN)

    security.declarePublic('getCalendarViewVocabulary')
    def getCalendarViewVocabulary(self):
        """Returns listing view vocabulary
        """
        dl = self.getCalendarViewDisplayList()
        return Vocabulary(dl, self, I18N_DOMAIN)

    def escapeText(self, text):
        """Escape chars on text. It can be very useful to use text in javascript

        :param text: text to escape
        """
        # If matching escapable char call this function
        def escape(match):
            """Escape chars
            """
            char = match.group(0)

            # Special chars already escaped. Apply double escape
            if char == '\n':
                return '\\n'
            elif char == '\r':
                return '\\n'
            elif char == '\t':
                return '\\t'

            return '\\%s' % char

        # Text must be an encoded string
        if not isinstance(text, basestring):
            raise ValueError("You can just escape strings: %s" % str(text))

        # Escape text
        return ESCAPE_CHARS.sub(escape, text)

    security.declareProtected(permissions.ManagePortal, 'clean_bookings')
    def clean_bookings(self, min_date=None, max_date=None):
        """ Clean outdated bookings with dates in provided interval.
        If max_date isn't prodvided, set to 6 month before current date.
        If min_date isn't prodvided, set to 6 month before max_date.
        If max_date and min_date aren't provided, cleaning interval is set as
        follow :
            min_date = (current_date - 12 months)
            max_date = (current_date - 6 months)
        :param min_date: oldest date
        :param max_date: recentest date
        """
        ctool = getToolByName(self, 'portal_catalog')

        if max_date is None:
            now_date = DateTime()
            mxdate_year = now_year = now_date.year()
            now_month = now_date.month()
            if now_month in (1, 2, 3, 4, 5, 6):
                mxdate_year = now_year - 1
                mxdate_month = 12 - 6 + now_month
            else:
                mxdate_month = now_month - 6
            str_mxdate = str(mxdate_year) + '/' + str(mxdate_month) + '/' + str(0) + str(1) 
            max_date = DateTime(str_mxdate)

        else:
            max_date = DateTime(max_date)
            if max_date > DateTime():
                return (False, "Max date should not be after the current date")

        if min_date is None:
            mndate_year = mxdate_year = max_date.year()
            mxdate_month = max_date.month()
            if mxdate_month in (1, 2, 3, 4, 5, 6):
                mndate_year = mxdate_year - 1
                mndate_month = 12 - 6 + mxdate_month
            else:
                mndate_month = mxdate_month - 6
            str_mndate = str(mndate_year) + '/' + str(0) + str(1) + '/' + str(mndate_month)
            min_date = DateTime(str_mndate)
        else:
            min_date = DateTime(min_date)
            if min_date > max_date:
                return (False, "Min date should not be after the max date")

        criteria = {
            "portal_type": "Booking",
            "getEndDate": dict(query=(min_date, max_date), range='minmax'),
        }

        booking_brains = ctool.searchResults(**criteria)

        brain_exception = []

        for brain in booking_brains:
            try:
                obj = brain.getObject()
                obj.restrictedTraverse('@@plone_lock_operations')\
                    .force_unlock(redirect=False)
                self.cancelBooking(obj)
            except:
                try:
                    brain_exception.append(brain.getPath())
                except KeyError:
                    print "Integrity error on %s" % brain.id
                    brain_exception.append(brain.id)

        nb_target = len(booking_brains)
        delta = len(brain_exception)
        nb_result = nb_target - delta

        msg = "Tried to delete %s booking(s) between %s and %s"
        msg = msg % (nb_target, min_date, max_date)
        if nb_target > 1:
            msg += "\n%s bookings have been deleted."
            msg = msg % nb_result
        if delta > 1:
            msg += "\n%s bookings could'nt have been deleted"
            msg = msg % delta

        return (True, msg)


InitializeClass(BookingTool)
