Calendar._SDN = new Array
("S\u00F8n",
 "Man",
 "Tir",
 "Ons",
 "Tor",
 "Fre",
 "L\u00F8r",
 "S\u00F8n");
 Calendar._TT["ABOUT"] =
"Datovalg:\n" +
"- Benyt \xab, \xbb  for at v\u00E6lge \u00E5r.\n" +
"- Benyt " + String.fromCharCode(0x2039) + ", " + String.fromCharCode(0x203a) + " for at v\u00E6lge m\u00E5ned\n" +
"- Hold musenknappen nede over denne knap for hurtigvalgsmenu.";

Calendar._TT["DEF_DATE_FORMAT"] = "%Y-%m-%d";