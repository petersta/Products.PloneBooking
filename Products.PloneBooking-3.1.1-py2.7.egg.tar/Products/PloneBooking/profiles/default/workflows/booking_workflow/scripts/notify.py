## Script (Python) "notify"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=state_change
##title=
##
context.booking_workflow_notification(state_change.object)
